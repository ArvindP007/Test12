﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace new_2nd_Task.Migrations
{
    public partial class kallu : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo");

            migrationBuilder.AlterColumn<int>(
                name: "userId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "credentialId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo",
                column: "userId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials",
                column: "credentialId",
                principalTable: "CredentialsInfo",
                principalColumn: "userId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo");

            migrationBuilder.AlterColumn<int>(
                name: "credentialId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "userId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo",
                column: "credentialId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials",
                column: "credentialId",
                principalTable: "CredentialsInfo",
                principalColumn: "credentialId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
