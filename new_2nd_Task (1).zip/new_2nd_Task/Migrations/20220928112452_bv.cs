﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace new_2nd_Task.Migrations
{
    public partial class bv : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_UserCredentials",
                table: "UserCredentials");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserCredentials",
                table: "UserCredentials",
                column: "credentialId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_UserCredentials",
                table: "UserCredentials");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserCredentials",
                table: "UserCredentials",
                columns: new[] { "credentialId", "UserId" });
        }
    }
}
