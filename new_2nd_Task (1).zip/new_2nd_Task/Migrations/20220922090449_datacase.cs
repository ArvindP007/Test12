﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace new_2nd_Task.Migrations
{
    public partial class datacase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials");

            migrationBuilder.DropForeignKey(
                name: "FK_UserCredentials_Usertable_UserId",
                table: "UserCredentials");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Usertable",
                table: "Usertable");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "Usertable");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "CredentialsInfo");

            migrationBuilder.AlterColumn<int>(
                name: "UserId",
                table: "Usertable",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "credentialId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Usertable",
                table: "Usertable",
                column: "UserId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo",
                column: "credentialId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials",
                column: "credentialId",
                principalTable: "CredentialsInfo",
                principalColumn: "credentialId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserCredentials_Usertable_UserId",
                table: "UserCredentials",
                column: "UserId",
                principalTable: "Usertable",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials");

            migrationBuilder.DropForeignKey(
                name: "FK_UserCredentials_Usertable_UserId",
                table: "UserCredentials");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Usertable",
                table: "Usertable");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo");

            migrationBuilder.AlterColumn<int>(
                name: "UserId",
                table: "Usertable",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "Usertable",
                type: "integer",
                nullable: false,
                defaultValue: 0)
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "credentialId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                defaultValue: 0)
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Usertable",
                table: "Usertable",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CredentialsInfo",
                table: "CredentialsInfo",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_UserCredentials_CredentialsInfo_credentialId",
                table: "UserCredentials",
                column: "credentialId",
                principalTable: "CredentialsInfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserCredentials_Usertable_UserId",
                table: "UserCredentials",
                column: "UserId",
                principalTable: "Usertable",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
