﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace new_2nd_Task.Migrations
{
    public partial class mhj : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Credentials",
                table: "UserCredentials");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Credentials",
                table: "UserCredentials",
                type: "text",
                nullable: false,
                defaultValue: "");
        }
    }
}
