﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace new_2nd_Task.Migrations
{
    public partial class dataabc : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "userId",
                table: "CredentialsInfo",
                type: "integer",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "userId",
                table: "CredentialsInfo");
        }
    }
}
