﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace new_2nd_Task.Migrations
{
    public partial class dbnew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
