﻿using Microsoft.EntityFrameworkCore;
using new_2nd_Task.EFCore;
using System.Reflection.Emit;

namespace Credentials_Module.EFCore
{
    public class EF_DataContext : DbContext
    {
        public EF_DataContext(DbContextOptions<EF_DataContext> options) : base(options) { }
        
         /*   protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserCredentials>().HasKey(sc => new { sc.UserId, sc.credentialId });

            modelBuilder.Entity<UserCredentials>()
            .HasOne<CredentialsInfoTable>(sc => sc.CredentialsInfoTable)
            .WithMany(s => s.UserCredentials)
            .HasForeignKey(sc => sc.credentialId);


            modelBuilder.Entity<UserCredentials>()
                .HasOne<Usertable>(sc => sc.Usertable)
                .WithMany(s => s.UserCredentials)
                .HasForeignKey(sc => sc.UserId);
        }*/
    



       protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<UserCredentials>()
               .HasOne(b => b.CredentialsInfoTable)
               .WithMany(br => br.UserCredentials)
               .HasForeignKey(b => b.credentialId);

            modelBuilder.Entity<UserCredentials>()
               .HasOne(b => b.Usertable)
               .WithMany(br => br.UserCredentials)
               .HasForeignKey(b => b.UserId);

            
        }
      /*  public IEnumerable<CredentialsInfoTable> GetUsercred1()
        {
            var list=(from p in _context.credentialsInfos
                join pm in _context.credentialsInfos on p.credentialId equals pm.credentialId

                join ud in_context.usertables on p.userID equals ud.userId
                select new UserCredentials()
                {
                    credentialId=p.credentialId,
                    UserId=ud.UserId,
                }).ToList();*/



        public DbSet<CredentialsInfoTable> credentialsInfos { get; set; }

        public DbSet<Usertable> usertables { get; set; }

        public DbSet<UserCredentials> userCredentials { get; set; }



    }
}

