﻿namespace Credentials_Module.Controllers
{
    public interface IHttpActionResult
    {
    }
}