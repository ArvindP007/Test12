﻿namespace new_2nd_Task.Model
{
    public class UserCredentialsModel
    {
        public int CredentialId { get; set; }
        public int UserId { get; set; }

        public string Credentials { get; set; }
    }
}
