﻿namespace new_2nd_Task.Model
{
    public class UsertableModel
    {
       // public int Id { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int Password { get; set; }
    }
}
