﻿namespace new_2nd_Task.Model
{
    public class CredInfoModel
    {
        //public int Id { get; set; }
         public int UserId { get; set; }
        public int credentialId { get; set; }
        public string credentialName { get; set; }
        public string credentialValue { get; set; }
    }
}
