﻿using AutoMapper;
using StudentWebAPI.Dtos.Character;
using StudentWebAPI.Models;

namespace StudentWebAPI
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Character, GetCharacterDto>();
            CreateMap<AddCharacterDto, Character>();
            CreateMap<UpdateCharacterDto, Character>();
        }
    }
}
