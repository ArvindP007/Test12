﻿namespace BasicAPI.Model
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; } = String.Empty;
        public int RollNo { get; set; }
    }
}
