﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnit_DemoProject
{
    public class EmployeeDetails
    {
        public int id { get; set; }
        public string Name { get; set; }
        public double salary { get; set; }
        public string Gender { get; set; }
    }
}
